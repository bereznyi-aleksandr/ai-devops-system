def run(cur, sql): return cur.execute(sql)
